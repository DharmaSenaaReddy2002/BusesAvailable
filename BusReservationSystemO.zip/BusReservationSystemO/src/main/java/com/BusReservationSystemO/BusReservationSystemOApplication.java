package com.BusReservationSystemO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusReservationSystemOApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusReservationSystemOApplication.class, args);
	}

}
